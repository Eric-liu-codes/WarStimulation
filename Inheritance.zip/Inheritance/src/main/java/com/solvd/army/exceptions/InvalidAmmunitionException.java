package com.solvd.army.exceptions;

public class InvalidAmmunitionException extends Exception{
    public InvalidAmmunitionException(String message){
        super(message);
    }
}

package com.solvd.army.generics;
import java.util.*;

public class DequeInterface {
    Deque<Integer> arrayDequeue = new ArrayDeque<Integer>(10);
}

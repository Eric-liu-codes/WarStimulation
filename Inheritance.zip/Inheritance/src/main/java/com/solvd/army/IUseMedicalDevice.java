package com.solvd.army;

public interface IUseMedicalDevice {
    void turnOnMachine(boolean machineOn);
    void useMachine(int inputData, String inputFName, String inputLName);
}

package com.solvd.army.generics;
import java.util.*;

public class MapInterface {
    Hashtable<Integer, String> hashtable = new Hashtable<>();
}

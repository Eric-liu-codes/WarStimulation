package com.solvd.army.exceptions;

public class NoNameException extends Exception{
    public NoNameException(String message){
        super(message);
    }
}

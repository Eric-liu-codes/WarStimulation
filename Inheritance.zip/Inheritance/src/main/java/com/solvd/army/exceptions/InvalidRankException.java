package com.solvd.army.exceptions;

public class InvalidRankException extends Exception{
    public InvalidRankException(String message){
        super(message);
    }
}

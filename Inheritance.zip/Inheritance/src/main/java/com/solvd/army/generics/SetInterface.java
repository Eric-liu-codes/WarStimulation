package com.solvd.army.generics;
import java.util.*;

public class SetInterface {
    HashSet<ArrayList> set = new HashSet<>();
    ArrayList<Integer> list = new ArrayList<>();
}

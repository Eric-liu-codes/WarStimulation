package com.solvd.army.generics;
import java.util.*;

public class QueueInterface {
    PriorityQueue<Integer> priorityQueue = new PriorityQueue<Integer>();
}

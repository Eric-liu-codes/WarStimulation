package com.solvd.army.exceptions;

public class NoOperatorException extends Exception{
    public NoOperatorException(String message){
        super(message);
    }
}

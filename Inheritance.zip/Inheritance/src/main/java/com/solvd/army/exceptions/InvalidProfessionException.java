package com.solvd.army.exceptions;

public class InvalidProfessionException extends Exception{
    public InvalidProfessionException(String message){
        super(message);
    }
}

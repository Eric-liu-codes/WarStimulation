package com.solvd.army.weapon;

public class Weapons {
    private Tank tanks;
    private Aircraft aircraft;
    private Submarine submarines;
    private Gun guns;

    public Weapons(Tank tanks, Aircraft aircraft, Submarine submarines, Gun guns) {
        this.tanks = tanks;
        this.aircraft = aircraft;
        this.submarines = submarines;
        this.guns = guns;
    }

    public Tank getTanks() {
        return tanks;
    }

    public void setTanks(Tank tanks) {
        this.tanks = tanks;
    }

    public Aircraft getAircraft() {
        return aircraft;
    }

    public void setAircraft(Aircraft aircraft) {
        this.aircraft = aircraft;
    }

    public Submarine getSubmarines() {
        return submarines;
    }

    public void setSubmarines(Submarine submarines) {
        this.submarines = submarines;
    }

    public Gun getGuns() {
        return guns;
    }

    public void setGuns(Gun guns) {
        this.guns = guns;
    }
}

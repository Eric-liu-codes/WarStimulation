package com.solvd.army;

public interface IUseGun {
    void useGun(boolean aiming, boolean firing, int ammunition);
    void reloading(boolean isReloading);
}

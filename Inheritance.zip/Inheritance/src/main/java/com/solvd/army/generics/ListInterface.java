package com.solvd.army.generics;
import java.util.*;

public class ListInterface {
    ArrayList<Integer> arrayList = new ArrayList<Integer>(5);
}
